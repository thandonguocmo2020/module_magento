<?php

	namespace NIIT\Demo\Block;

	class Demo extends \Magento\Framework\View\Element\Template{

		public function _prepareLayout(){
			return parent::_prepareLayout();
		}
	}
?>